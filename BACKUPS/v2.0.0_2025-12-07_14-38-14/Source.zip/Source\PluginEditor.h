#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"
#include "GUI/ModernLookAndFeel.h"
#include "GUI/AdvancedSpectrumDisplay.h"
#include "GUI/AIControlPanel.h"
#include "GUI/EQBandControl.h"
#include "GUI/AIProblemPanel.h"
#include "GUI/BandControlPanel.h"
#include "GUI/DynamicEQPanel.h"

//==============================================================================
/**
 * AI Equalizer Pro - TDR Nova Style GUI
 * 
 * ┌──────────────────────────────────────────────────────────────────────┐
 * │  ← → [Preset▼]          [A B] [A>B]     [PRE][POST]   [?][⚙][♥]     │
 * ├──────────────────────────────────────────────────────────────────────┤
 * │                                                                      │
 * │                     SPECTRUM ANALYZER                                │
 * │              ○I    ○II    ○III    ○IV                               │
 * │                                                                      │
 * ├──────────────────────────────────────────────────────────────────────┤
 * │  AI EQ PRO       [Band Selector]     [KNOBS]           [OUT GAIN]   │
 * │  Standard        I II III IV                                        │
 * └──────────────────────────────────────────────────────────────────────┘
 */
class AIEqualizerAudioProcessorEditor : public juce::AudioProcessorEditor,
                                         public juce::Timer
{
public:
    explicit AIEqualizerAudioProcessorEditor(AIEqualizerAudioProcessor&);
    ~AIEqualizerAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;
    void timerCallback() override;
    void mouseDoubleClick(const juce::MouseEvent&) override;

private:
    void createHeader();
    void createControlPanel();
    void createBands();
    void updateBandPositions();
    void onBandChanged(int idx, const EQBandControl::BandParameters& p);
    void selectBand(int bandIndex);
    
    float freqToX(float f);
    float gainToY(float g);
    float xToFreq(float x);
    float yToGain(float y);

    AIEqualizerAudioProcessor& processor;
    ModernLookAndFeel lookAndFeel;
    
    // Layout
    static constexpr int headerH = 38;
    static constexpr int controlH = 130;
    static constexpr int aiPanelW = 440;   // Larger panel for detailed AI problem display
    static constexpr int bandPanelH = 140;
    static constexpr int pad = 6;
    
    // Header
    juce::TextButton prevBtn{"<"}, nextBtn{">"};
    juce::ComboBox presetBox;
    juce::ToggleButton btnA{"A"}, btnB{"B"};
    juce::TextButton copyBtn{"A>B"};
    juce::ToggleButton btnPre{"PRE"}, btnPost{"POST"};
    juce::ToggleButton bypassBtn{"BYPASS"};
    
    // Control Panel
    juce::Label logoLabel, subtitleLabel;
    std::array<juce::ToggleButton, 8> bandToggles;
    juce::Label gainLabel, sensitivityLabel, strengthLabel, outLabel;
    juce::Slider gainKnob, sensitivityKnob, strengthKnob, outKnob;
    juce::Label gainValue, outValue;
    juce::ToggleButton autoBtn{"AUTO"};
    
    // Main
    std::unique_ptr<AdvancedSpectrumDisplay> spectrum;
    std::unique_ptr<AIProblemPanel> aiProblemPanel;
    juce::OwnedArray<EQBandControl> bands;
    juce::OwnedArray<BandControlPanel> bandPanels;
    
    // Selected band for detail view
    int selectedBand = 0;
    std::unique_ptr<BandControlPanel> selectedBandPanel;
    
    // Dynamic EQ controls
    std::unique_ptr<DynamicEQPanel> dynamicEQPanel;
    std::unique_ptr<DynamicEQMasterPanel> dynamicEQMasterPanel;
    
    juce::Rectangle<int> spectrumBounds;
    juce::Rectangle<int> graphBounds;
    
    // Attachments
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> 
        bypassAtt, preAtt, postAtt, autoAtt;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> 
        outAtt, sensitivityAtt, strengthAtt;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AIEqualizerAudioProcessorEditor)
};
