#include "NeuralNetworkWrapper.h"
#include "../Utils/Logger.h"
#include <fstream>
#include <atomic>
#include <cstring>

#if defined(AIEQ_ENABLE_TFLITE)
#include <tensorflow/lite/interpreter.h>
#include <tensorflow/lite/kernels/register.h>
#include <tensorflow/lite/model.h>
#endif

//==============================================================================
// Internal Implementation (will use libtorch if available)
class NeuralNetworkWrapper::Impl
{
public:
    Impl() {}
    ~Impl() {}
    
#if defined(AIEQ_ENABLE_TFLITE)
    bool hasInterpreter() const noexcept { return interpreter != nullptr; }
#endif

    bool loadModel(const juce::File& modelFile)
    {
#if defined(AIEQ_ENABLE_TFLITE)
        model = tflite::FlatBufferModel::BuildFromFile(modelFile.getFullPathName().toStdString().c_str());
        if (!model)
            return false;

        tflite::InterpreterBuilder builder(*model, resolver);
        if (builder(&interpreter) != kTfLiteOk || !interpreter)
            return false;

        if (interpreter->AllocateTensors() != kTfLiteOk)
            return false;

        return true;
#else
        juce::ignoreUnused(modelFile);
        return false;
#endif
    }
    
    void unloadModel()
    {
#if defined(AIEQ_ENABLE_TFLITE)
        interpreter.reset();
        model.reset();
#endif
    }
    
    InferenceResult runInference(const std::vector<float>& input)
    {
        InferenceResult result;

#if defined(AIEQ_ENABLE_TFLITE)
        if (!interpreter)
        {
            result.success = false;
            result.errorMessage = "TFLite interpreter not available";
            return result;
        }

        // Basic shape check: flatten into first input tensor
        float* inputTensor = interpreter->typed_input_tensor<float>(0);
        if (!inputTensor)
        {
            result.success = false;
            result.errorMessage = "TFLite input tensor null";
            return result;
        }

        const size_t tensorSize = static_cast<size_t>(interpreter->input_tensor(0)->bytes / sizeof(float));
        if (input.size() > tensorSize)
        {
            result.success = false;
            result.errorMessage = "Input size exceeds tensor capacity";
            return result;
        }

        std::fill(inputTensor, inputTensor + tensorSize, 0.0f);
        std::memcpy(inputTensor, input.data(), input.size() * sizeof(float));

        if (interpreter->Invoke() != kTfLiteOk)
        {
            result.success = false;
            result.errorMessage = "TFLite inference failed";
            return result;
        }

        float* outputTensor = interpreter->typed_output_tensor<float>(0);
        if (!outputTensor)
        {
            result.success = false;
            result.errorMessage = "TFLite output tensor null";
            return result;
        }

        const int outDims = interpreter->output(0)->dims->size;
        int outSize = 1;
        for (int i = 0; i < outDims; ++i)
            outSize *= interpreter->output(0)->dims->data[i];

        result.output.assign(outputTensor, outputTensor + outSize);
        result.success = true;
        return result;
#else
        juce::ignoreUnused(input);
        result.success = false;
        result.errorMessage = "Torch/TFLite backend not available";
        return result;
#endif
    }
    
    bool startTraining(const std::vector<TrainingSample>& samples, const TrainingConfig& config)
    {
        // TODO: Implement training
        return false;
    }
    
    void stopTraining()
    {
        // TODO: Implement training stop
    }
    
    bool saveModel(const juce::File& path)
    {
        // TODO: Implement model saving
        return false;
    }

#if defined(AIEQ_ENABLE_TFLITE)
private:
    std::unique_ptr<tflite::FlatBufferModel> model;
    std::unique_ptr<tflite::Interpreter> interpreter;
    tflite::ops::builtin::BuiltinOpResolver resolver;
#endif
};

//==============================================================================
NeuralNetworkWrapper::NeuralNetworkWrapper()
    : pImpl(std::make_unique<Impl>())
{
}

NeuralNetworkWrapper::~NeuralNetworkWrapper()
{
}

//==============================================================================
bool NeuralNetworkWrapper::loadModel(const juce::File& modelFile, ModelType type)
{
    std::lock_guard<std::mutex> lock(modelMutex);
    
    if (!modelFile.existsAsFile())
        return false;
    
    currentModel.type = type;
    currentModel.modelPath = modelFile.getFullPathName();
    currentModel.modelName = modelFile.getFileNameWithoutExtension();
    currentModel.isLoaded = pImpl->loadModel(modelFile);
    currentModel.loadTime = juce::Time::currentTimeMillis();
    
    if (!currentModel.isLoaded)
    {
        static std::atomic<bool> warnedTorchUnavailable { false };
        const bool firstWarning = !warnedTorchUnavailable.exchange(true, std::memory_order_acq_rel);
        if (firstWarning)
        {
            AIEQ_LOG_WARNING("Neural model not loaded (Torch backend unavailable). "
                             "AI features will fall back to classical ML.");
        }
    }
    
    return currentModel.isLoaded;
}

bool NeuralNetworkWrapper::loadModel(const juce::String& modelPath, ModelType type)
{
    return loadModel(juce::File(modelPath), type);
}

void NeuralNetworkWrapper::unloadModel()
{
    std::lock_guard<std::mutex> lock(modelMutex);
    
    pImpl->unloadModel();
    currentModel.isLoaded = false;
    currentModel.modelPath = juce::String();
    currentModel.modelName = juce::String();
}

//==============================================================================
NeuralNetworkWrapper::InferenceResult NeuralNetworkWrapper::runInference(const std::vector<float>& input)
{
    std::lock_guard<std::mutex> lock(modelMutex);
    
    if (!currentModel.isLoaded)
    {
        InferenceResult result;
        result.success = false;
        result.errorMessage = "No model loaded";
        
        static std::atomic<bool> warnedNoModel { false };
        const bool firstWarning = !warnedNoModel.exchange(true, std::memory_order_acq_rel);
        if (firstWarning)
        {
            AIEQ_LOG_WARNING("Neural inference skipped: no model loaded. "
                             "Load a Torch/TFLite model or disable NN features.");
        }
        return result;
    }
    
    auto startTime = juce::Time::getMillisecondCounterHiRes();
    auto result = pImpl->runInference(input);
    auto endTime = juce::Time::getMillisecondCounterHiRes();
    
    result.inferenceTimeMs = static_cast<float>(endTime - startTime);
    return result;
}

NeuralNetworkWrapper::InferenceResult NeuralNetworkWrapper::runInference(const std::vector<std::vector<float>>& input)
{
    // Flatten 2D input to 1D
    std::vector<float> flattened;
    for (const auto& row : input)
    {
        flattened.insert(flattened.end(), row.begin(), row.end());
    }
    
    return runInference(flattened);
}

//==============================================================================
bool NeuralNetworkWrapper::startOnlineTraining(const std::vector<TrainingSample>& samples,
                                               const TrainingConfig& config)
{
    std::lock_guard<std::mutex> lock(modelMutex);
    
    if (!currentModel.isLoaded)
        return false;
    
    if (isTrainingActive.load())
        return false;
    
    isTrainingActive = true;
    trainingProgress = 0.0f;
    
    return pImpl->startTraining(samples, config);
}

void NeuralNetworkWrapper::stopOnlineTraining()
{
    std::lock_guard<std::mutex> lock(modelMutex);
    
    pImpl->stopTraining();
    isTrainingActive = false;
    trainingProgress = 0.0f;
}

//==============================================================================
bool NeuralNetworkWrapper::saveFineTunedModel(const juce::File& outputPath)
{
    std::lock_guard<std::mutex> lock(modelMutex);
    
    if (!currentModel.isLoaded)
        return false;
    
    return pImpl->saveModel(outputPath);
}

bool NeuralNetworkWrapper::exportToONNX(const juce::File& outputPath)
{
    // TODO: Implement ONNX export
    return false;
}

//==============================================================================
juce::String NeuralNetworkWrapper::getModelTypeName(ModelType type)
{
    switch (type)
    {
        case ModelType::Unmasking: return "Unmasking";
        case ModelType::ProfileExtended: return "Profile Extended";
        case ModelType::DynamicAdaptive: return "Dynamic Adaptive";
        case ModelType::ProblemDetection: return "Problem Detection";
        case ModelType::Custom: return "Custom";
        default: return "Unknown";
    }
}

bool NeuralNetworkWrapper::isTorchAvailable()
{
    // TODO: Check if libtorch is linked
    return false;
}

juce::String NeuralNetworkWrapper::getTorchVersion()
{
    // TODO: Return actual torch version
    return "Not Available";
}

